﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerpustakaanAppMVC.Model.Entity
{
    public class Mahasiswa
    {
        public string Npm { get; set; }
        public string Nama { get; set; }
        public string Angkatan { get; set; }
    }
}
