﻿namespace PerpustakaanAppMVC.View
{
    internal class FrmSearchMahasiswa
    {
    }
}